/*!
 * Documenter 2.0
 * http://rxa.li/documenter
 *
 * Copyright 2011, Xaver Birsak
 * http://revaxarts.com
 *
 */
 
$(document).ready(function() {
	function exdoc_scroll($this){
		var Id_tm = $this.attr("id");
		var this_tl = $this;
		var $tl_top = this_tl.offset().top;
		var $tl_end = $tl_top + this_tl.height();
		$tl_top =  $tl_top -10;
		$tl_end =  $tl_end;
		if (($(document).scrollTop() >= $tl_top) && ($(document).scrollTop() <= $tl_end)) {
			$("#documenter_nav li a").removeClass('current');
			$("a[href$=#"+Id_tm+"]").addClass('current');
			$("#documenter_nav a.current").closest('li').find('ul').addClass('active');
		}
	}
	
	$(document).scroll(function() {
		$("#documenter_content > section").each(function(){
			var $this = jQuery(this);
			exdoc_scroll($this);		
		});
	});
	var hash = window.location.hash;
	hash = hash.replace("#", "");
	if( hash!=''){
		$("#documenter_nav li a").removeClass('current');
		$("#documenter_nav li a[data-id="+hash+"]").addClass('current');
		$("#documenter_nav a.current").closest('li').find('ul').addClass('active');
	}
	$("#documenter_nav li a").click(function(e){
		$("#documenter_nav li a").removeClass('current');
		$(this).addClass('current');
		var contenId = jQuery(this).data("id");
		e.preventDefault();	
		var windowHeight = $(window).height();
		$('html,body').animate({
			scrollTop: $("#"+contenId).offset().top - windowHeight * .01},
			'slow');	
	});
	
});