<?php

class Coinbase_TokensExpiredException extends Coinbase_Exception
{
}
